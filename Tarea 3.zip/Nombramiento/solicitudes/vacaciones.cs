﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombramiento
{
    class vacaciones
    {
        public static void solicitar_vacaciones(int localizacion)
        {
            int op = 0;
            clear.clean();
            Console.WriteLine("Desea solicitar vacaciones para " + tablaADM.Lista[localizacion + 1] + "?\n");
            Console.WriteLine("1-Si/n2-No\n\nSu opcion: ");
            op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1: agregarVacaciones(localizacion);
                    break;
                case 2:
                    clear.clean();
                    Console.WriteLine("Ingrese cedula: ");
                    string cedula = Convert.ToString(Console.ReadLine());
                    busqueda.buscador(cedula);
                    break;
            }
        }

        private static void agregarVacaciones(int localizacion)
        {
            string fecha;
            ClaseDatos.estado_laboral = "Vacaciones";
            clear.clean();
            Console.WriteLine("Cuando quiere iniciar las vacaciones?\nIngrese formato dia/mes/año con los slash");
            fecha = Console.ReadLine();
            ClaseDatos.fecha_inicio = fecha;
            DateTime fechaDesde = DateTime.Parse(fecha);
            tablaADM.Lista[localizacion + 6] = fecha;
            clear.clean();
            Console.WriteLine("Cuando quiere iniciar las vacaciones?\nIngrese formato dia/mes/año con los slash");
            fecha = Console.ReadLine();
            ClaseDatos.fecha_hasta = fecha;
            tablaADM.Lista[localizacion + 7] = fecha;
            DateTime fechaHasta = DateTime.Parse(fecha);
            TimeSpan resta = fechaHasta.Subtract(fechaDesde);
            int dias_vacaciones = resta.Days;
            Console.WriteLine(tablaADM.Lista[localizacion + 1] + " Tendra " + dias_vacaciones + " Dias de vacaciones");
            print.printer();
        }
    }
}
