﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombramiento
{
    class Permiso
    {
        public static void solicitarPermiso(int localizacion)
        {
            string fecha;

            clear.clean();
            Console.WriteLine("Cuando quiere Solicitar el permiso?\nIngrese formato dia/mes/año con los slash");
            fecha = Console.ReadLine();
            ClaseDatos.fecha_inicio = fecha;
            DateTime fechaDesde = DateTime.Parse(fecha);
            tablaADM.Lista[localizacion + 6] = fecha;
            ClaseDatos.estado_laboral = "Permiso";
            clear.clean();
            Console.WriteLine("Cuando quiere iniciar las vacaciones?\nIngrese formato dia/mes/año con los slash");
            fecha = Console.ReadLine();
            tablaADM.Lista[localizacion + 7] = fecha;

            ClaseDatos.fecha_hasta = fecha;
            DateTime fechaHasta = DateTime.Parse(fecha);
            TimeSpan resta = fechaHasta.Subtract(fechaDesde);
            int dias_vacaciones = resta.Days;
            if (dias_vacaciones < 3)
            {
                Console.WriteLine("No puede solicitar una fecha tan larga de permiso");
            }
            Console.WriteLine(tablaADM.Lista[localizacion + 1] + " Tendra " + dias_vacaciones + " Dias de Permiso");

        }
    }
}
