﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombramiento
{
    class desvinculacion
    {
        public static void solicitarDesvinculacion(int localizacion)
        {
            int op =0;
            Console.WriteLine("Desea desvincular a:" + tablaADM.Lista[localizacion + 1]);
            Console.WriteLine("1-Si\n2-No\n");
            op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1:
                    Proceso_desvinculacion(localizacion);
                    break;

                case 2:
                    clear.clean();
                    Console.WriteLine("Ingrese cedula: ");
                    string cedula = Convert.ToString(Console.ReadLine());
                    busqueda.buscador(cedula);
                    break;
            }
        }

        private static void Proceso_desvinculacion(int localizacion)
        {
            ClaseDatos.estado_laboral = "Desvinculado";
            string motivo;
            clear.clean();
            Console.WriteLine("Por que se desvinculara?\n");
            motivo = Console.ReadLine();
            ClaseDatos.motivoDesvinculado = motivo;
            clear.clean();
            Console.WriteLine("Lamentamos dejarte partir");
            print.printer();

        }
    }
}
