﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombramiento
{
    class busqueda
    {
        
        public static void buscador(String cedula)
        {
            int localizador = 0;
             for(int i = 0; i < tablaADM.Lista.Count; i+=9)
             {
                 if (tablaADM.Lista[i] == cedula)
                 {
                    localizador = i;
                     break;
                 }
                clear.clean();
             }
            printer(localizador);
        }
        public static void printer(int localizacion)
        {
            clear.clean();
            Console.WriteLine("Dato encontrado\n\n");
            Console.WriteLine("Cedula: "+tablaADM.Lista[localizacion]);
            ClaseDatos.NombreCompleto_empleado = tablaADM.Lista[localizacion + 1];
            Console.WriteLine("Nombre: "+tablaADM.Lista[localizacion+ 1]);
            ClaseDatos.salarioPorHora = Convert.ToInt32(tablaADM.Lista[localizacion + 2]);
            Console.WriteLine("Sueldo: "+tablaADM.Lista[localizacion + 2]);
            ClaseDatos.cuenta= Convert.ToInt32(tablaADM.Lista[localizacion + 3]);
            Console.WriteLine("Numero de cuenta: "+tablaADM.Lista[localizacion + 3]);
            ClaseDatos.tanda =tablaADM.Lista[localizacion + 4];
            Console.WriteLine("Tanda laboral: "+tablaADM.Lista[localizacion + 4]);
            ClaseDatos.estado_laboral = tablaADM.Lista[localizacion + 5];
            Console.WriteLine("Estado laboral: "+tablaADM.Lista[localizacion + 5]);
            solicitud(localizacion);
            //Desde 6
            //hasta 7
        }

        public static void solicitud(int localizacion)
        {
            int op = 0;
            Console.WriteLine("\n\nElija que solicitud hara: \n");
            Console.WriteLine("1-Vacaciones\n2-Permiso");
            Console.Write("\n3-Desvinculacion\nSu opcion: ");
            op = Convert.ToInt32(Console.ReadLine());
            switch (op)
            {
                case 1: vacaciones.solicitar_vacaciones(localizacion);
                    break;
                case 2:
                    Permiso.solicitarPermiso(localizacion);
                    break;
                case 3:
                    desvinculacion.solicitarDesvinculacion(localizacion);
                    break;
            }
        }
         
        }

}

