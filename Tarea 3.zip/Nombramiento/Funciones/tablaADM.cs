﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombramiento
{
    class tablaADM
    {
        public static List<string> Lista = new List<string>();
        public static void getDato()
        {
            
        }
        public static void setDato()
        {

        }
    }
}
