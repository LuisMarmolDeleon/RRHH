﻿using System;

namespace Nombramiento
{
    class Program
    {

        static void Main(string[] args)
        {
            bienvenida();
        }

        internal static int getsalario(int salario)
        {
            return salario;
        }  
        
        public static void bienvenida()
        {
            int opp = 0;
            string cedula;
            Console.WriteLine("RRHH BY Luis Marmol\n\n\n");
            Console.WriteLine("Seleccione una opcion:\n\n");
            Console.WriteLine("1-Registrar personal\n");
            Console.WriteLine("2-Solicitudes\n");
            Console.Write("3-Salir\n\nSu Opcion: ");
            opp = Convert.ToInt32(Console.ReadLine());
            switch (opp)
            {
                case 1:
                    clear.clean();
                    registro_empleado.Registro_empleado();
                    break;

                case 2:
                    clear.clean();
                    Console.WriteLine("Ingrese numero de cedula");
                    cedula=Console.ReadLine();
                    busqueda.buscador(cedula);
             
                    break;

                case 3:
                   
                    break;
            }
        }
    }
}
