﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombramiento
{
    class opcion
    {
        public static void metodo_pago()
        {
            int op = 0, res = 0, bucl = 1;
                Console.WriteLine("Especifique el horario de trabajo de " + ClaseDatos.NombreCompleto_empleado + "\n\n");
                Console.WriteLine("1- Tiempo Completo\n2- Medio Tiempo.\n3- Temporal.\n\nSu opcion");
                op = Convert.ToInt32(Console.ReadLine());
                switch (op)
                {
                    case 1:
                        res = 1;
                        break;

                    case 2:
                        res = 2;
                        break;

                    case 3:
                        res = 3;
                        break;
                }
                InterfazEmpleados emp = factory.Getter(res);
                emp.tandaEmpleo();
                emp.metodopago();
                emp.Salario_PorHora();
                emp.salario_porMes();

                if (res == 1 || res == 2)
                {
                    clear.clean();
                    Console.WriteLine("Ingrese un numero de cuentas:\n");
                    ClaseDatos.cuenta = Convert.ToInt32(Console.ReadLine());
                    tablaADM.Lista.Add(Convert.ToString(ClaseDatos.cuenta));
                }
                else if (res == 3)
                {
                    ClaseDatos.cuenta = 0;
                    tablaADM.Lista.Add("Cheque");
                }
                if (res == 1)
                {
                    tablaADM.Lista.Add("Tiempo Completo (8Hrs)");
                }else if (res == 2)
                {
                    tablaADM.Lista.Add("Medio Tiempo (4Hrs)");
                }else if (res == 3)
                {
                    tablaADM.Lista.Add("Temporal (8Hrs)");
                }
                tablaADM.Lista.Add("Laborando");
                tablaADM.Lista.Add("...");
                tablaADM.Lista.Add("...");

                print.printer();
                clear.clean();

                  Console.WriteLine(tablaADM.Lista[0]+"\n"); //cedula
                  Console.WriteLine(tablaADM.Lista[1] + "\n");// nombre
                 Console.WriteLine(tablaADM.Lista[2] + "\n"); //sueldo
                 Console.WriteLine(tablaADM.Lista[3] + "\n"); //numero de cuenta
                 Console.WriteLine(tablaADM.Lista[4] + "\n"); //Tiempo laboral
                 Console.WriteLine(tablaADM.Lista[5] + "\n"); //Estado
                 Console.WriteLine(tablaADM.Lista[6] + "\n"); //desde
                 Console.WriteLine(tablaADM.Lista[7] + "\n");//hasta
                Console.WriteLine("Agrego a:" + ClaseDatos.NombreCompleto_empleado + ".\n\n Desea agregar mas?\n");
                Console.WriteLine("1-Si\n0-No\n\n");
                Console.Write("Su opcion: ");
                bucl = Convert.ToInt32(Console.ReadLine());
            if (bucl == 1)
            {
                registro_empleado.Registro_empleado();
            }
            else
            {
                Program.bienvenida();
            }

        }
    }
}
